package br.com.fiap.cp1.service;

import org.springframework.stereotype.Service;

@Service
public class TarefaService {

}
